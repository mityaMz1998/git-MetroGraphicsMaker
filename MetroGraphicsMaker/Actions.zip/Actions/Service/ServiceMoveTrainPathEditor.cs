﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class ServiceMoveTrainPathEditor : BaseEdit
    {
        private List<int> MemoryTimeStartFirstStation;
        private List<int> StartTimeBeginTail;
        private List<TrainPath> EditTrainPaths;
        private int DeltaTime;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public ServiceMoveTrainPathEditor(List<TrainPath> Selected, ListTrainPaths _MasterTrainPaths)
            : base(Selected[0], _MasterTrainPaths)
        {
            MemoryTimeStartFirstStation = new List<int>();
            StartTimeBeginTail = new List<int>();
            EditTrainPaths = new List<TrainPath>();
            foreach (TrainPath thTrainPath in Selected)
            {
                MemoryTimeStartFirstStation.Add(thTrainPath.TimeStartFirstStation);
                if (thTrainPath.TailTrainPath != null)
                {
                    StartTimeBeginTail.Add(thTrainPath.TailTrainPath.TimeBeginTail);
                }
                EditTrainPaths.Add(thTrainPath);
            }
            MasterTrainPaths = _MasterTrainPaths;
        }

        public ServiceMoveTrainPathEditor(List<TrainPath> Selected)
            : base(Selected[0], null)
        {
            MemoryTimeStartFirstStation = new List<int>();
            StartTimeBeginTail = new List<int>();
            EditTrainPaths = new List<TrainPath>();
            foreach (TrainPath thTrainPath in Selected)
            {
                MemoryTimeStartFirstStation.Add(thTrainPath.TimeStartFirstStation);
                if (thTrainPath.TailTrainPath != null)
                {
                    StartTimeBeginTail.Add(thTrainPath.TailTrainPath.TimeBeginTail);
                }
                EditTrainPaths.Add(thTrainPath);
            }
            MasterTrainPaths = null;
        }

        public override Boolean Check(int _DeltaTime)
        {
            DeltaTime = _DeltaTime;
            return true;
        }

        public override void Do()
        {
            int OffsetIntoTheStartMarginsTrainTails = 0;
            for (int i = 0; i < EditTrainPaths.Count; i++)
            {
                EditTrainPaths[i].TimeStartFirstStation = (MemoryTimeStartFirstStation[i] + DeltaTime);
                EditTrainPaths[i].InvalidateVisual();
                if (EditTrainPaths[i].TailTrainPath != null)
                {
                    EditTrainPaths[i].TailTrainPath.TimeBeginTail = StartTimeBeginTail[i - OffsetIntoTheStartMarginsTrainTails] + DeltaTime;
                    EditTrainPaths[i].TailTrainPath.InvalidateVisual();
                }
                else
                {
                    OffsetIntoTheStartMarginsTrainTails++;
                }
            }

            if (!isModify && MasterTrainPaths != null) //Регистрация в журналах выполненых пользователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
            }
            isModify = true;
        }

        public override void Undo()
        {
            int OffsetIntoTheStartMarginsTrainTails = 0;
            for (int i = 0; i < EditTrainPaths.Count; i++)
            {
                EditTrainPaths[i].TimeStartFirstStation = MemoryTimeStartFirstStation[i];
                EditTrainPaths[i].InvalidateVisual();
                if (EditTrainPaths[i].TailTrainPath != null)
                {
                    EditTrainPaths[i].TailTrainPath.TimeBeginTail = StartTimeBeginTail[i - OffsetIntoTheStartMarginsTrainTails];
                    EditTrainPaths[i].TailTrainPath.InvalidateVisual();
                }
                else
                {
                    OffsetIntoTheStartMarginsTrainTails++;
                }
            }
        }
    }
}
