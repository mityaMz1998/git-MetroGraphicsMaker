﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using View;

namespace Actions
{
    static class SelectTrainPath
    {
        public static void PrimarySelectOrDeSelectTrainPath(TrainPath FreeOrPrimaryTrainPath)
        {
            switch (FreeOrPrimaryTrainPath.Condition)
            {
                case ConditionTrainPath.Free:
                    FreeOrPrimaryTrainPath.Condition = ConditionTrainPath.PrimarySelected;
                    FreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Add(FreeOrPrimaryTrainPath);
                    FreeOrPrimaryTrainPath.InvalidateVisual();
                    break;
                case ConditionTrainPath.PrimarySelected:
                    FreeOrPrimaryTrainPath.Condition = ConditionTrainPath.Free;
                    FreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Remove(FreeOrPrimaryTrainPath);
                    FreeOrPrimaryTrainPath.InvalidateVisual();
                    break;
                default:
                    throw new System.ArgumentException("FreeOrPrimaryTrainPath.Condition должен быть равен PrimerySelected или Free", "original");
            }

            SecondarySelectOrDeSelectTrainPath(FreeOrPrimaryTrainPath);

            SelectOrDeselectTailPrivaryTrainPath(FreeOrPrimaryTrainPath);
        }

        private static void SecondarySelectOrDeSelectTrainPath(TrainPath PrimaryTrainPath)
        {
            ConditionTrainPath MemoryCondition;
            switch (PrimaryTrainPath.Condition)
            {
                case ConditionTrainPath.Free:
                    MemoryCondition = ConditionTrainPath.Free;
                    break;
                case ConditionTrainPath.PrimarySelected:
                    MemoryCondition = ConditionTrainPath.SecondarySelected;
                    break;
                default:
                    throw new System.ArgumentException("PrimaryTrainPath.Condition должен быть равен PrimerySelected или Free", "original");
            }

            TrainPath thTrainPath = PrimaryTrainPath;
            while (thTrainPath.Back != null)
            {
                thTrainPath.Back.Condition = MemoryCondition;
                if (MemoryCondition == ConditionTrainPath.SecondarySelected)
                {
                    thTrainPath.MasterTrainPaths.SecondarySelectedTrainPaths.Add(thTrainPath.Back);
                }
                else
                {
                    thTrainPath.MasterTrainPaths.SecondarySelectedTrainPaths.Remove(thTrainPath.Back);
                }
                thTrainPath.Back.InvalidateVisual();

                if (thTrainPath.Back.TailTrainPath != null)
                {
                    SelectOrDeselectTailTrainPath(thTrainPath.Back);
                }
                thTrainPath = thTrainPath.Back;
            }

            thTrainPath = PrimaryTrainPath;
            while (thTrainPath.Next != null)
            {
                thTrainPath.Next.Condition = MemoryCondition;
                if (MemoryCondition == ConditionTrainPath.SecondarySelected)
                {
                    thTrainPath.MasterTrainPaths.SecondarySelectedTrainPaths.Add(thTrainPath.Next);
                }
                else
                {
                    thTrainPath.MasterTrainPaths.SecondarySelectedTrainPaths.Remove(thTrainPath.Next);
                }
                thTrainPath.Next.InvalidateVisual();

                if (thTrainPath.Next.TailTrainPath != null)
                {
                    SelectOrDeselectTailTrainPath(thTrainPath.Next);
                }
                thTrainPath = thTrainPath.Next;
            }
        }

        private static void SelectOrDeselectTailTrainPath(TrainPath thTrainPath)
        {
                thTrainPath.TailTrainPath.Condition = thTrainPath.Condition;
                thTrainPath.TailTrainPath.InvalidateVisual();
        }

        private static void SelectOrDeselectTailPrivaryTrainPath(TrainPath PrimaryTrainPath)
        {
            if (PrimaryTrainPath.TailTrainPath!=null)
            {
                PrimaryTrainPath.TailTrainPath.Condition = PrimaryTrainPath.Condition;
                PrimaryTrainPath.TailTrainPath.InvalidateVisual();
            }
            if (PrimaryTrainPath.Back!=null)
            {
                PrimaryTrainPath.Back.TailTrainPath.Condition = PrimaryTrainPath.Condition;
                PrimaryTrainPath.Back.TailTrainPath.InvalidateVisual();
            }
        }

        public static void PrimarySelectOrDeSelectTrainPaths(TrainPath SecondFreeOrPrimaryTrainPath)
        {
            if (SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Count() == 0)
            {
                throw new System.ArgumentException("MasterTrainPaths.PrimarySelectedTrainPaths.Count() не может быть равен 0", "original");
            }
            if (SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[0].DirectionTrainPath != SecondFreeOrPrimaryTrainPath.DirectionTrainPath)
            {
                throw new System.ArgumentException("Direction у ниток должен быть одинаков", "original");
            }

            int FirstTimeStartFirstStation;
            int SecondTimeStartFirstStation;
            List<TrainPath> SelectTrainPaths;
            switch (SecondFreeOrPrimaryTrainPath.Condition)
            {
                case ConditionTrainPath.Free:
                    if (SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Count() > 1)
                    {
                        throw new System.ArgumentException("MasterTrainPaths.PrimarySelectedTrainPaths.Count() не может быть больше 1 при SecondFreeOrPrimaryTrainPath.Condition=Free", "original");
                    }
                    
                    if (SecondFreeOrPrimaryTrainPath.TimeStartFirstStation > SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.First().TimeStartFirstStation)
                    {
                        FirstTimeStartFirstStation = SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.First().TimeStartFirstStation;
                        SecondTimeStartFirstStation = SecondFreeOrPrimaryTrainPath.TimeStartFirstStation;
                    }
                    else
                    {
                        FirstTimeStartFirstStation = SecondFreeOrPrimaryTrainPath.TimeStartFirstStation;
                        SecondTimeStartFirstStation = SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.First().TimeStartFirstStation;
                    }
                    break;
                case ConditionTrainPath.PrimarySelected:
                    if (SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Count() == 1)
                    {
                        throw new System.ArgumentException("MasterTrainPaths.PrimarySelectedTrainPaths.Count() не может быть равен 1 при SecondFreeOrPrimaryTrainPath.Condition=PrimarySelected", "original");
                    }

                    FirstTimeStartFirstStation=SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[0].TimeStartFirstStation;
                    SecondTimeStartFirstStation=SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[0].TimeStartFirstStation;
                    for (int Number = 1; Number < SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths.Count; Number++)
                    {
                        if (FirstTimeStartFirstStation>SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[Number].TimeStartFirstStation)
                        {
                            FirstTimeStartFirstStation=SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[Number].TimeStartFirstStation;
                        }
                        if (SecondTimeStartFirstStation < SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[Number].TimeStartFirstStation)
                        {
                            SecondTimeStartFirstStation = SecondFreeOrPrimaryTrainPath.MasterTrainPaths.PrimarySelectedTrainPaths[Number].TimeStartFirstStation;
                        }
                    }
                    if (SecondTimeStartFirstStation != SecondFreeOrPrimaryTrainPath.TimeStartFirstStation && FirstTimeStartFirstStation != SecondFreeOrPrimaryTrainPath.TimeStartFirstStation)
                    {
                        throw new System.ArgumentException("SecondFreeOrPrimaryTrainPath не является первой или последней Primary ниткой на графике по времени TimeStartFirstStation", "original");
                    }
                    break;
                default:
                    throw new System.ArgumentException("SecondFreeOrPrimaryTrainPath.Condition должен быть равен PrimerySelected или Free", "original");
            }
            SelectTrainPaths = SecondFreeOrPrimaryTrainPath.MasterTrainPaths.TrainPaths.FindAll(thTrainPath => FirstTimeStartFirstStation < thTrainPath.TimeStartFirstStation && SecondTimeStartFirstStation > thTrainPath.TimeStartFirstStation && SecondFreeOrPrimaryTrainPath.DirectionTrainPath == thTrainPath.DirectionTrainPath && SecondFreeOrPrimaryTrainPath.Condition == thTrainPath.Condition);

            PrimarySelectOrDeSelectTrainPath(SecondFreeOrPrimaryTrainPath);
            SelectTrainPaths.ForEach(thTrainPath => PrimarySelectOrDeSelectTrainPath(thTrainPath));
        }
    }
}
