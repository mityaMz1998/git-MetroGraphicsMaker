﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

using Actions;
using Core;
using View;
using Converters;

namespace Actions.Processes
{

    enum ResultDoOperation
    { 
        GOOD = 0,

        BAD = 1
    }

    class StacProcess : BaseEdit
    {
        private Int32 _startTime;
        private Int32 _endTime;
        private Int32 _specifiedPair;
        private Int32 _calculatedInterval;
        private Int32 _totalTrain;
        private Int32 _timeFrom1To2;
        private Int32 _timeFrom2To1;
        private Direction _selectedDirection;

        private Stack<BaseEdit> MovePrimaryTrainPathEditors = new Stack<BaseEdit>();
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="startTime">Время начала процесса</param>
        /// <param name="endTime">Время окончания процесса</param>
        /// <param name="specifiedPair">Заданная парность</param>
        /// <param name="calculatedInterval">Расчетный интервал</param>
        /// <param name="totalTrain">Доступное количество составов</param>
        /// <param name="timeFrom1To2">Время оборота с 1-го пути на 2-й</param>
        /// <param name="timeFrom2To1">Время оборота со 2-го пути на 1-й</param>
        /// <param name="selectedDirection">Направление, с которого начинается построение</param>
        /// <param name="MasterTrainPaths">Доступ к коллекции ниток</param>
        public StacProcess(Int32 startTime, Int32 endTime, Int32 specifiedPair, Int32 calculatedInterval, Int32 totalTrain,
                                             Int32 timeFrom1To2, Int32 timeFrom2To1, Direction selectedDirection, ListTrainPaths MasterTrainPaths)
            : base(null, MasterTrainPaths)
        {
            _startTime = startTime;
            _endTime = endTime;
            _specifiedPair = specifiedPair;
            _calculatedInterval=calculatedInterval;
            _totalTrain = totalTrain;
            _timeFrom1To2 = timeFrom1To2;
            _timeFrom2To1 = timeFrom2To1;
            _selectedDirection = selectedDirection;
        }
        public void Analyze(ResultDoOperation result)
        {
            switch (result)
            {
                case ResultDoOperation.GOOD:
                    var res = MessageBox.Show("Да - показать, нет - продолжить", "Заголовок", MessageBoxButton.YesNoCancel, MessageBoxImage.Information);
                    switch (res)
                    {
                        case MessageBoxResult.Yes:
                            MessageBox.Show("Показываем"); 
                            break;
                        case MessageBoxResult.No: 
                            MessageBox.Show("Продолжаем"); 
                            break;
                        case MessageBoxResult.Cancel:
                            MessageBox.Show("Отменяем");
                            Undo();
                            break;
                    }
                    break;

                case ResultDoOperation.BAD: 
                    return;
            }
        }

        public ResultDoOperation MyDo()
        {
            do
            {        
                _startTime += _calculatedInterval;
                var direct = _selectedDirection;
                CreateTrainPathEditor TrainPathCreator = new CreateTrainPathEditor(MasterTrainPaths, _startTime, _selectedDirection);
                if (TrainPathCreator.Check())
                {
                    TrainPathCreator.Do();
                    MovePrimaryTrainPathEditors.Push(TrainPathCreator);
                    CreateTrainPathEditor TrainPathCreator1 = new CreateTrainPathEditor(MasterTrainPaths, _startTime + _timeFrom1To2, _selectedDirection.contrDirection);
                    if (TrainPathCreator1.Check())
                    {
                        TrainPathCreator1.Do();
                        MovePrimaryTrainPathEditors.Push(TrainPathCreator1);
                    }
                }
            } while (_startTime <= _endTime);
            return ResultDoOperation.GOOD;
        }
        public override void Undo()
        {
            while (MovePrimaryTrainPathEditors.Count > 0)
            {
                MovePrimaryTrainPathEditors.Pop().Undo();
            }
        }
    }
}
