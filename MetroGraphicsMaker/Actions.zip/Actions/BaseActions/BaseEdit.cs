﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using View;
using Core;

namespace Actions
{
    public class BaseEdit
    {
        public TrainPath CTrainPath; 
        public int memoryTimeStartFirstStation; 
        public ListTrainPaths MasterTrainPaths; 

        public BaseEdit(TrainPath _СallingTrainPath, ListTrainPaths _MasterTrainPaths)
        {
            CTrainPath = _СallingTrainPath;
            if (_СallingTrainPath != null)
            {
                memoryTimeStartFirstStation = _СallingTrainPath.TimeStartFirstStation;
            }

            MasterTrainPaths = _MasterTrainPaths;
        }

        public virtual Boolean Check(int NewPositionTime)
        {
            return false;
        }

        public virtual Boolean Check()
        {
            return false;
        }

        public virtual Boolean Check(Boolean ButtonMouse, int NumberStation) //ButtonMouse - Выбор направления удаления точек: false удаляет левые относительно позиции NumberStation, true правые.
        {
            return false;
        }

        public virtual Boolean Check(int _StartTimeTrainPath, DirectionValue _DirectionTrainPath) //DirectionTrainPath - направление нитки: "Снизу вверх" или "Сверху вниз". True - Снизу вверх.
        {
            return false;
        }

        public virtual void Do()
        {

        }

        public virtual void Undo()
        {

        }
    }
}
