﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class DeleteTrainPathEditor : BaseEdit
    {
        private CreateOrDeleteСonnectionTrainPathsEditor DeleteTailEditorForNext = null;
        private CreateOrDeleteСonnectionTrainPathsEditor DeleteTailEditorForBack = null;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public DeleteTrainPathEditor(TrainPath _DeleteTrainPath, ListTrainPaths _MasterTrainPaths)
            : base(_DeleteTrainPath, _MasterTrainPaths)
        {

        }

        public override Boolean Check()
        {
            if (CTrainPath.Back == null && CTrainPath.Next != null)
            {
                DeleteTailEditorForNext = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath, CTrainPath.Next, null);
                return DeleteTailEditorForNext.Check();
            }
            else
            {
                if (CTrainPath.Back != null && CTrainPath.Next == null)
                {
                    DeleteTailEditorForBack = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath.Back, CTrainPath, null);
                    return DeleteTailEditorForBack.Check();
                }
                else
                {
                    if (CTrainPath.Back != null && CTrainPath.Next != null)
                    {
                        DeleteTailEditorForNext = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath, CTrainPath.Next, null);
                        DeleteTailEditorForBack = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath.Back, CTrainPath, null);
                        if (DeleteTailEditorForBack.Check() && DeleteTailEditorForNext.Check())
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        public override void Do()
        {
            MasterTrainPaths.TrainPaths.Remove(CTrainPath);
            MasterTrainPaths.Children.Remove(CTrainPath);

            if (DeleteTailEditorForNext != null)
            {
                DeleteTailEditorForNext.Do();
            }
            if (DeleteTailEditorForBack != null)
            {
                DeleteTailEditorForBack.Do();
            }

            if (!isModify) //Регистрация в журналах выполненых польхователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
                isModify = true;
            }
        }

        public override void Undo()
        {
            MasterTrainPaths.TrainPaths.Add(CTrainPath);
            MasterTrainPaths.Children.Add(CTrainPath);
            if (DeleteTailEditorForBack != null)
            {
                DeleteTailEditorForBack.Undo();
            }
            if (DeleteTailEditorForNext != null)
            {
                DeleteTailEditorForNext.Undo();
            }
        }
    }
}
