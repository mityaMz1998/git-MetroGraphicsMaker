﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class MovePrimaryTrainPathEditor : BaseEdit
    {
        private int MemoryTimeStartFirstStation;
        private int MemoryTimeStartNextTail=0;
        private int MemoryTimeStartBackTail=0;
        private List<int> NextTailTime = new List<int>();
        private List<int> BackTailTime = new List<int>();
       // private TrainPath EditPrimaryTrainPath;
        private int DeltaTime;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public MovePrimaryTrainPathEditor(TrainPath PrimaryTrainPath, ListTrainPaths _MasterTrainPaths)
            : base(PrimaryTrainPath, _MasterTrainPaths)
        {
            MemoryTimeStartFirstStation = PrimaryTrainPath.TimeStartFirstStation;
            if (PrimaryTrainPath.Back != null) 
            {
                MemoryTimeStartBackTail = PrimaryTrainPath.Back.TailTrainPath.TimeBeginTail;
                            foreach (int thTime in PrimaryTrainPath.Back.TailTrainPath.Time)
                            {
                BackTailTime.Add(thTime);
                            }
            }
            if (PrimaryTrainPath.Next != null) 
            {
                MemoryTimeStartNextTail = PrimaryTrainPath.TailTrainPath.TimeBeginTail;
                                            foreach (int thTime in PrimaryTrainPath.TailTrainPath.Time)
                            {
                NextTailTime.Add(thTime);
                            }
            }
            
            MasterTrainPaths = _MasterTrainPaths;
        }

        public MovePrimaryTrainPathEditor(TrainPath PrimaryTrainPath)
            : base(PrimaryTrainPath, null)
        {
            MemoryTimeStartFirstStation = PrimaryTrainPath.TimeStartFirstStation;
            if (PrimaryTrainPath.Back != null)
            {
                MemoryTimeStartBackTail = PrimaryTrainPath.Back.TailTrainPath.TimeBeginTail;
                foreach (int thTime in PrimaryTrainPath.Back.TailTrainPath.Time)
                {
                    BackTailTime.Add(thTime);
                }
            }
            if (PrimaryTrainPath.Next != null)
            {
                MemoryTimeStartNextTail = PrimaryTrainPath.TailTrainPath.TimeBeginTail;
                foreach (int thTime in PrimaryTrainPath.TailTrainPath.Time)
                {
                    NextTailTime.Add(thTime);
                }
            }
        }

        //public MoveTrainPathEditor(List<TrainPath> Selected)
        //    : base(Selected[0], null)
        //{
        //    MemoryTimeStartFirstStation = new List<int>();
        //    StartTimeBeginTail = new List<int>();
        //    EditTrainPaths = new List<TrainPath>();
        //    foreach (TrainPath thTrainPath in Selected)
        //    {
        //        MemoryTimeStartFirstStation.Add(thTrainPath.TimeStartFirstStation);
        //        if (thTrainPath.TailTrainPath != null)
        //        {
        //            StartTimeBeginTail.Add(thTrainPath.TailTrainPath.TimeBeginTail);
        //        }
        //        EditTrainPaths.Add(thTrainPath);
        //    }
        //    MasterTrainPaths = null;
        //}

        public override Boolean Check(int _DeltaTime)
        {
            DeltaTime = _DeltaTime;
            return true;
        }

        public override void Do()
        {
            CTrainPath.TimeStartFirstStation = MemoryTimeStartFirstStation + DeltaTime;
            CTrainPath.InvalidateVisual();

            if (CTrainPath.Back != null)
            {
                CTrainPath.Back.TailTrainPath.Time.Clear();
                CTrainPath.Back.TailTrainPath.Time.Add(0);
                CTrainPath.Back.TailTrainPath.Time.Add(0);

                int EndFirstTrainPath = CTrainPath.Back.TimeStartFirstStation + CTrainPath.Back.MasElRasp.Last().departureTime;
                int TimeOutTail = Math.Abs(CTrainPath.TimeStartFirstStation - EndFirstTrainPath);
                if (EndFirstTrainPath > CTrainPath.TimeStartFirstStation)
                {
                    CTrainPath.Back.TailTrainPath.TimeBeginTail = CTrainPath.TimeStartFirstStation;
                }
                else
                {
                    CTrainPath.Back.TailTrainPath.TimeBeginTail = EndFirstTrainPath;
                }
                CTrainPath.Back.TailTrainPath.Time.Add(TimeOutTail);
                CTrainPath.Back.TailTrainPath.Time.Add(TimeOutTail);

                CTrainPath.Back.TailTrainPath.InvalidateVisual();
            }
            if (CTrainPath.Next != null)
            {
                CTrainPath.TailTrainPath.Time.Clear();
                CTrainPath.TailTrainPath.Time.Add(0);
                CTrainPath.TailTrainPath.Time.Add(0);

                int EndFirstTrainPath = CTrainPath.TimeStartFirstStation + CTrainPath.MasElRasp.Last().departureTime;
                int TimeOutTail = Math.Abs(CTrainPath.Next.TimeStartFirstStation - EndFirstTrainPath);
                if (EndFirstTrainPath > CTrainPath.Next.TimeStartFirstStation)
                {
                    CTrainPath.TailTrainPath.TimeBeginTail = CTrainPath.Next.TimeStartFirstStation;
                }
                else
                {
                    CTrainPath.TailTrainPath.TimeBeginTail = EndFirstTrainPath;
                }
                CTrainPath.TailTrainPath.Time.Add(TimeOutTail);
                CTrainPath.TailTrainPath.Time.Add(TimeOutTail);

                CTrainPath.TailTrainPath.InvalidateVisual();
            }

            if (!isModify && MasterTrainPaths != null) //Регистрация в журналах выполненых пользователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
            }
            isModify = true;
        }

        public override void Undo()
        {
            CTrainPath.TimeStartFirstStation = MemoryTimeStartFirstStation;
            CTrainPath.InvalidateVisual();

            if (CTrainPath.Back != null)
            {
                CTrainPath.Back.TailTrainPath.TimeBeginTail = MemoryTimeStartBackTail;

                CTrainPath.Back.TailTrainPath.Time.Clear();
                BackTailTime.ForEach(thTime => CTrainPath.Back.TailTrainPath.Time.Add(thTime));
                //CTrainPath.Back.TailTrainPath.Time = BackTailTime;

                CTrainPath.Back.TailTrainPath.InvalidateVisual();
            }
            if (CTrainPath.Next != null)
            {
                CTrainPath.TailTrainPath.TimeBeginTail = MemoryTimeStartNextTail;

                CTrainPath.TailTrainPath.Time.Clear();
                NextTailTime.ForEach(thTime => CTrainPath.TailTrainPath.Time.Add(thTime));
                //CTrainPath.TailTrainPath.Time = NextTailTime;

                CTrainPath.TailTrainPath.InvalidateVisual();
            }
        }
    }
}
