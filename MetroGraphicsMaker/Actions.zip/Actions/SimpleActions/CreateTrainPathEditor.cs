﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{

    class CreateTrainPathEditor : BaseEdit
    {
        private TrainPath StartTrainPath;
        private int StartTimeTrainPath;

        private Direction DirectionTrainPath; //DirectionTrainPath - направление нитки: "Снизу вверх" или "Сверху вниз". True - Снизу вверх. 

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public CreateTrainPathEditor(ListTrainPaths _MasterTrainPaths, int _StartTimeTrainPath, Direction _DirectionTrainPath)
            : base(null, _MasterTrainPaths)
        {
            StartTimeTrainPath = _StartTimeTrainPath;
            DirectionTrainPath = _DirectionTrainPath;
        }

        public override Boolean Check() //DirectionTrainPath - направление нитки: "Снизу вверх" или "Сверху вниз". True - Снизу вверх.
        {
            return true;
        }

        public override void Do()
        {
            StartTrainPath = new TrainPath(StartTimeTrainPath, DirectionTrainPath, RegimeOfMotion.Nonpeak, MasterTrainPaths);

            if (!isModify) //Регистрация в журналах выполненых польхователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
                isModify = true;
            }
        }

        public override void Undo()
        {
            MasterTrainPaths.TrainPaths.Remove(StartTrainPath);
            MasterTrainPaths.Children.Remove(StartTrainPath);
        }
    }
}
