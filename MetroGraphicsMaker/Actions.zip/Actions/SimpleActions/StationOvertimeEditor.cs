﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class StationOvertimeEditor : BaseEdit
    {
        //private List<int> memoryTimeDepart = new List<int>();
        //private List<int> memoryTimeArrive = new List<int>();
        public List<clsElementOfSchedule> memoryMasElRasp = new List<clsElementOfSchedule>();

        private int IndexEditStation;
        private Boolean boolEditTimeArrive;
        private int DeltaTime;

        private ServiceMoveTrainPathEditor BackTrainPathMove;
        private int StartTimeBeginTail;
        private ServiceMoveTrainPathEditor NextTrainPathMove;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public StationOvertimeEditor(TrainPath _TrainPath, int _IndexEditStation, Boolean _EditTimeArrive, ListTrainPaths _MasterTrainPaths)
            : base(_TrainPath, _MasterTrainPaths) //EditTimeArrive - какая станционная точка является опорной: прибытие или отправление. True - прибытие. False - отправление.
        {
            foreach (clsElementOfSchedule thElementOfSchedule in _TrainPath.MasElRasp) memoryMasElRasp.Add(new clsElementOfSchedule((int)thElementOfSchedule.arrivalTime, (int)thElementOfSchedule.TimeStoyanOtprav, (int)thElementOfSchedule.departureTime, thElementOfSchedule.task));
            IndexEditStation = _IndexEditStation;
            boolEditTimeArrive = _EditTimeArrive;
            MasterTrainPaths = _MasterTrainPaths;

            if (_TrainPath.TailTrainPath != null)
            {
                StartTimeBeginTail = _TrainPath.TailTrainPath.TimeBeginTail;
            }

            List<TrainPath> Selected = new List<TrainPath>();

            _TrainPath.BackSelected(Selected);
            if (Selected.Count > 0)
            {
                BackTrainPathMove = new ServiceMoveTrainPathEditor(Selected);
            }
            else
            {
                BackTrainPathMove = null;
            }

            Selected.Clear();

            _TrainPath.NextSelected(Selected);
            if (Selected.Count > 0)
            {
                NextTrainPathMove = new ServiceMoveTrainPathEditor(Selected);
            }
            {
                NextTrainPathMove = null;
            }
        }

        public override Boolean Check(int _DeltaTime)
        {
            DeltaTime = _DeltaTime;

            int DeltaTimePointsStation = (int)(memoryMasElRasp[IndexEditStation].departureTime - memoryMasElRasp[IndexEditStation].arrivalTime);

            if (boolEditTimeArrive)
            {
                if (memoryMasElRasp[IndexEditStation].arrivalTime + DeltaTime >= memoryMasElRasp[IndexEditStation].departureTime)
                {
                    if (BackTrainPathMove == null && NextTrainPathMove == null)
                    {
                        ;
                    }
                    else
                    {
                        if (BackTrainPathMove == null && NextTrainPathMove != null)
                        {
                            return NextTrainPathMove.Check(DeltaTime - DeltaTimePointsStation);
                        }
                        else
                        {
                            if (BackTrainPathMove != null && NextTrainPathMove == null)
                            {
                                return BackTrainPathMove.Check(DeltaTimePointsStation);
                            }
                            else
                            {
                                if (BackTrainPathMove != null && NextTrainPathMove != null)
                                {
                                    if (BackTrainPathMove.Check(DeltaTimePointsStation) && NextTrainPathMove.Check(DeltaTime - DeltaTimePointsStation))
                                    {
                                        return true;
                                    }
                                }
                                else
                                {
                                    return false;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (BackTrainPathMove != null) return BackTrainPathMove.Check(DeltaTime);
                }
            }
            else
            {
                if (memoryMasElRasp[IndexEditStation].departureTime + DeltaTime < memoryMasElRasp[IndexEditStation].arrivalTime)
                {
                    if (BackTrainPathMove == null && NextTrainPathMove == null)
                    {
                        ;
                    }
                    else
                    {
                        if (BackTrainPathMove == null && NextTrainPathMove != null)
                        {
                            return NextTrainPathMove.Check(-DeltaTimePointsStation);
                        }
                        else
                        {
                            if (BackTrainPathMove != null && NextTrainPathMove == null)
                            {
                                return BackTrainPathMove.Check(DeltaTime + DeltaTimePointsStation);
                            }
                            else
                            {
                                if (BackTrainPathMove != null && NextTrainPathMove != null)
                                {
                                    if (BackTrainPathMove.Check(DeltaTime + DeltaTimePointsStation) && NextTrainPathMove.Check(-DeltaTimePointsStation))
                                    {
                                        return true;
                                    }
                                    else
                                    {
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (NextTrainPathMove != null)
                    {
                        return NextTrainPathMove.Check(DeltaTime);
                    }
                }
            }

            return true;
        }

        public override void Do()
        {
            int WorkEditStation = IndexEditStation;

            List<clsElementOfSchedule> FinishMasElRasp = new List<clsElementOfSchedule>();
            for (int i = 0; i <= WorkEditStation; i++)
            {
                FinishMasElRasp.Add(new clsElementOfSchedule((int)memoryMasElRasp[i].arrivalTime, (int)memoryMasElRasp[i].TimeStoyanOtprav, (int)memoryMasElRasp[i].departureTime, memoryMasElRasp[i].task));
            }

            int WorkDeltaTime = DeltaTime;


            //Выполнение перемещения ниток и хвостов на время DeltaTime + Учет возможности перехода редактирования с одной точки на другую в пределах одной станции
            int DeltaTimePointsStation = (int)(memoryMasElRasp[IndexEditStation].departureTime - memoryMasElRasp[IndexEditStation].arrivalTime);
            if (boolEditTimeArrive)
            {
                if (WorkDeltaTime >= DeltaTimePointsStation)
                {
                    // Учет возможности перехода редактирования с одной точки на другую в пределах одной станции  

                    CTrainPath.TimeStartFirstStation = memoryTimeStartFirstStation + DeltaTimePointsStation;
                    if (BackTrainPathMove != null)
                    {
                        //BackTrainPathMove.Do();
                    }
                    WorkDeltaTime = WorkDeltaTime - DeltaTimePointsStation;
                    if (CTrainPath.TailTrainPath != null)
                    {
                        CTrainPath.TailTrainPath.TimeBeginTail = StartTimeBeginTail + WorkDeltaTime;
                        CTrainPath.TailTrainPath.InvalidateVisual();
                        //NextTrainPathMove.Do();
                    }
                    WorkDeltaTime = WorkDeltaTime - DeltaTimePointsStation;
                }
                else
                {
                    CTrainPath.TimeStartFirstStation = memoryTimeStartFirstStation + WorkDeltaTime;
                    if (BackTrainPathMove != null)
                    {
                        BackTrainPathMove.Do();
                    }
                    WorkDeltaTime = -WorkDeltaTime;
                }
            }
            else
            {
                if (WorkDeltaTime <= -DeltaTimePointsStation)
                {
                    // Учет возможности перехода редактирования с одной точки на другую в пределах одной станции
                    if (CTrainPath.TailTrainPath != null)
                    {
                        CTrainPath.TailTrainPath.TimeBeginTail = StartTimeBeginTail - DeltaTimePointsStation;
                        CTrainPath.TailTrainPath.InvalidateVisual();
                        NextTrainPathMove.Do();
                    }
                    WorkDeltaTime = WorkDeltaTime + DeltaTimePointsStation;
                    CTrainPath.TimeStartFirstStation = memoryTimeStartFirstStation + WorkDeltaTime;
                    if (BackTrainPathMove != null)
                    {
                        BackTrainPathMove.Do();
                    }
                    WorkDeltaTime = -(WorkDeltaTime + DeltaTimePointsStation);
                }
                else
                {
                    if (CTrainPath.TailTrainPath != null)
                    {
                        CTrainPath.TailTrainPath.TimeBeginTail = StartTimeBeginTail + WorkDeltaTime;
                        CTrainPath.TailTrainPath.InvalidateVisual();
                        NextTrainPathMove.Do();
                    }
                }

            }
            FinishMasElRasp[WorkEditStation].departureTime = FinishMasElRasp[WorkEditStation].departureTime + WorkDeltaTime;
            ++WorkEditStation;

            //Выполнение перемещения точек на время DeltaTime
            for (; WorkEditStation < memoryMasElRasp.Count; WorkEditStation++)
            {
                FinishMasElRasp.Add(new clsElementOfSchedule((int)memoryMasElRasp[WorkEditStation].arrivalTime + WorkDeltaTime, 0, memoryMasElRasp[WorkEditStation].departureTime + WorkDeltaTime, memoryMasElRasp[WorkEditStation].task));
                //FinishTimeArrive.Add(memoryMasElRasp[WorkEditStation].arrivalTime + WorkDeltaTime);
                //FinishTimeDepart.Add(memoryMasElRasp[WorkEditStation].departureTime + WorkDeltaTime);
            }

            if (!isModify) //Регистрация в журналах выполненых польхователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
                isModify = true;
            }
            //CTrainPath.TimeArrive = FinishTimeArrive;
            //CTrainPath.TimeDepart = FinishTimeDepart;

            CTrainPath.MasElRasp = FinishMasElRasp;

            CTrainPath.InvalidateVisual();
        }

        public override void Undo()
        {
            //CTrainPath.TimeArrive = memoryTimeArrive;
            //CTrainPath.TimeDepart = memoryTimeDepart;
            CTrainPath.MasElRasp = memoryMasElRasp;
            CTrainPath.InvalidateVisual();

            if (BackTrainPathMove != null)
            {
                BackTrainPathMove.Undo();
            }
            CTrainPath.TimeStartFirstStation = memoryTimeStartFirstStation;
            if (CTrainPath.TailTrainPath != null)
            {
                CTrainPath.TailTrainPath.TimeBeginTail = StartTimeBeginTail;
                CTrainPath.TailTrainPath.InvalidateVisual();
            }
            if (NextTrainPathMove != null)
            {
                NextTrainPathMove.Undo();
            }
        }
    }
}
