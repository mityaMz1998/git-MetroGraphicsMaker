﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class CreateOrDeleteСonnectionTrainPathsEditor : BaseEdit //Переписать в терминах секунд. 
    {
        private TrainPath TrainPathFirst;
        private TrainPath TrainPathSecond;

        private Boolean ResultWasConnection; //Флаг того, какое действие было сделано. true - соеденены нитки, false - резедененены нитки.
        private Tail TailIfDelete = null; //Удаленный хвост, если ResultWasConnection = false; Нужно для простого отменены операции
        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public CreateOrDeleteСonnectionTrainPathsEditor(TrainPath First, TrainPath Second, ListTrainPaths _MasterTrainPaths)
            : base(First, _MasterTrainPaths)
        {
            if (First.TimeStartFirstStation + First.MasElRasp[First.NumberLastStation].departureTime < Second.TimeStartFirstStation + Second.MasElRasp[First.NumberFirstStation].departureTime) //Переписать в терминах секунд. 
            {
                TrainPathFirst = First;
                TrainPathSecond = Second;
            }
            else
            {
                TrainPathFirst = Second;
                TrainPathSecond = First;
            }
        }

        public override Boolean Check() //Переписать в терминах секунд. 
        {
            if (TrainPathFirst.Node.Last().Y == TrainPathSecond.Node[0].Y && (TrainPathFirst.TailTrainPath == null || TrainPathFirst.Next == TrainPathSecond) && (TrainPathSecond.Back == null || TrainPathSecond.Back == TrainPathFirst))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override void Do()
        {
            if (TrainPathFirst.TailTrainPath == null)
            {
                TrainPathFirst.TailTrainPath = new Tail(30, TrainPathFirst, TrainPathSecond, TrainPathSecond.MasterTrainPaths);
                MasterTrainPaths.TailsTrainPaths.Add(TrainPathFirst.TailTrainPath);
                MasterTrainPaths.Children.Add(TrainPathFirst.TailTrainPath);
                TrainPathFirst.TailTrainPath.InvalidateVisual();

                TrainPathFirst.Next = TrainPathSecond;
                TrainPathSecond.Back = TrainPathFirst;

                ResultWasConnection = true;
            }
            else
            {
                TrainPathFirst.MasterTrainPaths.TailsTrainPaths.Remove(TrainPathFirst.TailTrainPath);
                TrainPathFirst.MasterTrainPaths.Children.Remove(TrainPathFirst.TailTrainPath);

                TailIfDelete = TrainPathFirst.TailTrainPath;
                TailIfDelete.Condition = ConditionTrainPath.Free;
                TrainPathFirst.TailTrainPath = null;
                TrainPathFirst.Next = null;
                TrainPathSecond.Back = null;

                ResultWasConnection = false;
            }

            if (!isModify && MasterTrainPaths != null) //Регистрация в журналах выполненых польхователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
            }
            isModify = true;
        }
        //return next
        public override void Undo()
        {
            if (ResultWasConnection)
            {
                TrainPathFirst.MasterTrainPaths.TailsTrainPaths.Remove(TrainPathFirst.TailTrainPath);
                TrainPathFirst.MasterTrainPaths.Children.Remove(TrainPathFirst.TailTrainPath);

                TrainPathFirst.TailTrainPath = null;
                TrainPathFirst.Next = null;
                TrainPathSecond.Back = null;
            }
            else
            {
                TrainPathFirst.Next = TrainPathSecond;
                TrainPathSecond.Back = TrainPathFirst;
                TrainPathFirst.TailTrainPath = TailIfDelete;

                TrainPathFirst.MasterTrainPaths.TailsTrainPaths.Add(TailIfDelete);
                TrainPathFirst.MasterTrainPaths.Children.Add(TailIfDelete);
            }
        }
    }
}
