﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using View;

namespace Actions
{
    class LengthOfTrainPathEditor : BaseEdit
    {
        private int StartNumberFirstStation;
        private int StartNumberLastStation;
        private Boolean DirectionOfRemoval;
        private int NumberStation;

        private CreateOrDeleteСonnectionTrainPathsEditor DeleteСonnectionTrainPaths = null;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public LengthOfTrainPathEditor(TrainPath Selected, ListTrainPaths _MasterTrainPaths)
            : base(Selected, _MasterTrainPaths)
        {
            StartNumberFirstStation = Selected.NumberFirstStation;
            StartNumberLastStation = Selected.NumberLastStation;
        }

        public override Boolean Check(Boolean _DirectionOfRemoval, int _NumberStation) //ButtonMouse - Выбор направления удаления точек: false удаляет левые относительно позиции NumberStation, true правые.
        {
            DirectionOfRemoval = _DirectionOfRemoval;
            NumberStation = _NumberStation;
            if (NumberStation >= 0)
            {
                if (_DirectionOfRemoval)
                {
                    if (CTrainPath.TailTrainPath != null)
                    {
                        DeleteСonnectionTrainPaths = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath, CTrainPath.Next, null);
                        return DeleteСonnectionTrainPaths.Check();
                    }
                    else
                    {
                        DeleteСonnectionTrainPaths = null;
                        return true;
                    }
                }
                else
                {
                    if (CTrainPath.Back != null)
                    {
                        DeleteСonnectionTrainPaths = new CreateOrDeleteСonnectionTrainPathsEditor(CTrainPath.Back, CTrainPath, null);
                        return DeleteСonnectionTrainPaths.Check();
                    }
                    else
                    {
                        DeleteСonnectionTrainPaths = null;
                        return true;
                    }
                }
            }
            else
            {
                return false;
            }
        }

        public override void Do()
        {
            if (DirectionOfRemoval)
            {
                CTrainPath.NumberLastStation = NumberStation;
            }
            else
            {
                CTrainPath.NumberFirstStation = NumberStation;
            }

            if (DeleteСonnectionTrainPaths != null)
            {
                DeleteСonnectionTrainPaths.Do();
            }

            if (!isModify) //Регистрация в журналах выполненых польхователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
                isModify = true;
            }
        }

        public override void Undo()
        {
            CTrainPath.NumberFirstStation = StartNumberFirstStation;
            CTrainPath.NumberLastStation = StartNumberLastStation;
            if (DeleteСonnectionTrainPaths != null)
            {
                DeleteСonnectionTrainPaths.Undo();
            }
            CTrainPath.InvalidateVisual();
        }
    }
}
