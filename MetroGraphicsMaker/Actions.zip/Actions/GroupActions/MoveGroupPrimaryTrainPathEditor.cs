﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Windows.Controls;
using Core;
using View;

namespace Actions
{
    class MoveGroupPrimaryTrainPathEditor : BaseEdit
    {
        private List<TrainPath> EditTrainPaths;
        
        private Stack<MovePrimaryTrainPathEditor> MovePrimaryTrainPathEditors = new Stack<MovePrimaryTrainPathEditor>();

        private int DeltaTime;

        private Boolean isModify = false; //Использовалось ли изменение данного типа или нет.

        public MoveGroupPrimaryTrainPathEditor(List<TrainPath> SelectedPrimaryTrainPaths, ListTrainPaths _MasterTrainPaths)
            : base(SelectedPrimaryTrainPaths[0], _MasterTrainPaths)
        {
            EditTrainPaths = SelectedPrimaryTrainPaths;
            EditTrainPaths.ForEach(thTrainPath => MovePrimaryTrainPathEditors.Push(new MovePrimaryTrainPathEditor(thTrainPath)));
        }

        public override Boolean Check(int _DeltaTime)
        {
            if (MovePrimaryTrainPathEditors.All(el => el.Check(DeltaTime)))
          //  if (!MovePrimaryTrainPathEditors.Where(thMoveEditor => !thMoveEditor.Check(DeltaTime)).Any())
            {
                DeltaTime = _DeltaTime;
                return true;
            }
            return false;
        }

        public override void Do()
        {

            MovePrimaryTrainPathEditors.Select(el => { el.Do(); return true; });

            //MovePrimaryTrainPathEditors.ForEach(thMoveEditor => thMoveEditor.Do());

            if (!isModify && MasterTrainPaths != null) //Регистрация в журналах выполненых пользователем операций
            {
                MasterTrainPaths.StackAllDoOperation.Push(this);
                MasterTrainPaths.StackAllUndoOperation.Clear();
            }
            isModify = true;
        }

        public override void Undo()
        {
            while (MovePrimaryTrainPathEditors.Count > 0)
            {
                MovePrimaryTrainPathEditors.Pop().Undo();
            }
           // MovePrimaryTrainPathEditors.ForEach(thMoveEditor => thMoveEditor.Undo());
        }
    }
}
